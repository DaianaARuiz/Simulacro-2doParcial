
char getChar(char message[],char messageError[], char answer1, char answer2);

int getWord(char wordValue[], char message[]);

int getInt(char message[],char messageError[], int min, int max);

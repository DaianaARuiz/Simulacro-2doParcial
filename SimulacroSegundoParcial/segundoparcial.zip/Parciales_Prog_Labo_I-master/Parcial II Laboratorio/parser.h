#include "LinkedList.h"

int Parser_generarListaVuelos(FILE* pFile, LinkedList* listaDeVuelos);

int Parser_guardarVuelosCortosEnArchivo(FILE* pFile, LinkedList* listaDeVuelos);

int Parser_generarListaPilotos(FILE* pFile, LinkedList* listaDePilotos);

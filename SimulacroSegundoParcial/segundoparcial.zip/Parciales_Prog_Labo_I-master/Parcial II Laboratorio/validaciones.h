int getInt(char message[],char messageError[], int min, int max);

float getFloat(char message[],char messageError[], float min, float max);

char getChar(char message[],char messageError[], char answer1, char answer2);

int getWord(char wordValue[], char message[]);
